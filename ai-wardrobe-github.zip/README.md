# AI WARDROBE

ตู้เสื้อผ้าดิจิทัลและ AI Stylist ส่วนตัว (เว็บแอป ไม่มี backend) ใช้งานออฟไลน์ได้หลังเปิดครั้งแรก

## วิธีขึ้น GitHub Pages
1. สร้าง repository ใหม่บน GitHub (เช่นชื่อ `ai-wardrobe`) แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ไว้ที่ราก (รวมโฟลเดอร์ `.github` และไฟล์ `.nojekyll`)
2. ไปที่ **Settings > Pages > Build and deployment > Source** เลือก **GitHub Actions**
3. รอแท็บ **Actions** ทำงานเสร็จ ลิงก์จะเป็น `https://<ชื่อผู้ใช้>.github.io/ai-wardrobe/`

(ทางเลือก: เลือก Source เป็น "Deploy from a branch" > `main` > `/ (root)` แล้วลบโฟลเดอร์ `.github` ได้)

## ติดตั้งบนมือถือ
- iPhone: เปิดลิงก์ด้วย Safari > Share > Add to Home Screen
- Android: Chrome > เมนู > Install app

## อัปเดตแอป
แก้ `index.html` แล้วเปลี่ยนเลข `aiw-v1` ใน `sw.js` (เช่น `aiw-v2`) เพื่อให้เครื่องที่ติดตั้งไว้ดึงเวอร์ชันใหม่

## หมายเหตุ
- ข้อมูลทั้งหมดเก็บใน localStorage ของเบราว์เซอร์ ไม่มีบัญชีผู้ใช้หรือเซิร์ฟเวอร์ ล้างข้อมูลเบราว์เซอร์แล้วข้อมูลจะหาย
- ระบบ AI เป็น Mock แบบกฎ (อ่านสีจากพิกเซลของรูปจริง) ฟังก์ชันที่ต้องแทนด้วย AI API อยู่ในออบเจ็กต์ `AI` ใน `index.html` (`recognize`, `generate`)
- ปุ่มค้นหา Pinterest เปิดหน้าค้นหาภายนอก ไม่ได้เชื่อม Pinterest API
